import { createClient } from "@/lib/supabase/client";

/*
 * --------------------------------------------------------------------------
 * | MATCH-LOBBY
 * --------------------------------------------------------------------------
 *
 * Geteilter Zustand für die Phase VOR dem eigentlichen Match: Ein Spieler
 * eröffnet ein Match (createMatchLobby), andere treten über den Link
 * /spieler/match/<id> mit ihrem Profil bei (joinMatchLobby). Änderungen
 * werden per Supabase Realtime an alle verbundenen Geräte verteilt.
 * --------------------------------------------------------------------------
 */

export type LobbyStatus = "lobby" | "live" | "finished";

export type MatchLobby = {
  id: string;
  status: LobbyStatus;
  teamAPlayerIds: string[];
  teamBPlayerIds: string[];
};

type LobbyRow = {
  id: string;
  status: LobbyStatus;
  team_a_player_ids: string[] | null;
  team_b_player_ids: string[] | null;
};

function mapRow(row: LobbyRow): MatchLobby {
  return {
    id: row.id,
    status: row.status,
    teamAPlayerIds: row.team_a_player_ids ?? [],
    teamBPlayerIds: row.team_b_player_ids ?? [],
  };
}

const LOBBY_COLUMNS = "id, status, team_a_player_ids, team_b_player_ids";

/*
 * --------------------------------------------------------------------------
 * | LOBBY ERSTELLEN
 * --------------------------------------------------------------------------
 */

export async function createMatchLobby(): Promise<MatchLobby> {
  const supabase = createClient();

  const { data, error } = await supabase
    .from("match_lobbies")
    .insert({})
    .select(LOBBY_COLUMNS)
    .single();

  if (error) {
    throw error;
  }

  rememberHostedLobby((data as LobbyRow).id);

  return mapRow(data as LobbyRow);
}

/*
 * --------------------------------------------------------------------------
 * | ERSTELLER DER LOBBY
 * --------------------------------------------------------------------------
 *
 * Nur wer die Lobby eröffnet hat, darf das Match starten. Der Ersteller
 * wird auf dem Gerät gemerkt, auf dem createMatchLobby() lief (gleiches
 * Prinzip wie das Host-Gerät beim Match selbst) - wer per QR-Code oder
 * Link beitritt, ist damit automatisch kein Ersteller. Funktioniert auch
 * ohne Login. Öffnet der Ersteller die Lobby auf einem anderen Gerät oder
 * löscht er die Browserdaten, ist er dort kein Ersteller mehr.
 * --------------------------------------------------------------------------
 */

const HOSTED_LOBBIES_KEY = "bpst:hosted-lobbies";
const HOSTED_LOBBIES_MAX = 50;

function readHostedLobbies(): string[] {
  try {
    const raw = window.localStorage.getItem(HOSTED_LOBBIES_KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : [];

    return Array.isArray(parsed) ? parsed.filter((id): id is string => typeof id === "string") : [];
  } catch {
    return [];
  }
}

function rememberHostedLobby(lobbyId: string): void {
  try {
    const ids = readHostedLobbies().filter((id) => id !== lobbyId);

    /* Nur die letzten Lobbys behalten, damit der Speicher nicht wächst. */
    window.localStorage.setItem(
      HOSTED_LOBBIES_KEY,
      JSON.stringify([...ids, lobbyId].slice(-HOSTED_LOBBIES_MAX)),
    );
  } catch {
    /* Speicher gesperrt: dann kann dieses Gerät die Lobby nicht als Ersteller starten. */
  }
}

/** true, wenn diese Lobby auf DIESEM Gerät eröffnet wurde. */
export function isLobbyHost(lobbyId: string): boolean {
  return readHostedLobbies().includes(lobbyId);
}

/*
 * --------------------------------------------------------------------------
 * | LOBBY LADEN
 * --------------------------------------------------------------------------
 */

export async function getMatchLobby(id: string): Promise<MatchLobby | null> {
  const supabase = createClient();

  const { data, error } = await supabase
    .from("match_lobbies")
    .select(LOBBY_COLUMNS)
    .eq("id", id)
    .maybeSingle();

  if (error) {
    throw error;
  }

  if (!data) {
    return null;
  }

  return mapRow(data as LobbyRow);
}

/*
 * --------------------------------------------------------------------------
 * | LOBBY BEITRETEN
 * --------------------------------------------------------------------------
 *
 * HINWEIS: Liest den aktuellen Stand und schreibt ihn zurück. Bei zwei
 * Spielern, die im exakt gleichen Sekundenbruchteil beitreten, kann das
 * theoretisch einen Beitritt überschreiben (kein atomares DB-Update).
 * Für ein Beerpong-Turnier unter Freunden ist das ein akzeptables Risiko;
 * für echte Robustheit bräuchte es eine Postgres-Funktion (RPC).
 * --------------------------------------------------------------------------
 */

export async function joinMatchLobby(
  lobbyId: string,
  playerId: string,
  team: "A" | "B",
): Promise<MatchLobby> {
  const current = await getMatchLobby(lobbyId);

  if (!current) {
    throw new Error("Lobby nicht gefunden.");
  }

  const teamAPlayerIds = current.teamAPlayerIds.filter((id) => id !== playerId);
  const teamBPlayerIds = current.teamBPlayerIds.filter((id) => id !== playerId);

  if (team === "A") {
    teamAPlayerIds.push(playerId);
  } else {
    teamBPlayerIds.push(playerId);
  }

  const supabase = createClient();

  const { data, error } = await supabase
    .from("match_lobbies")
    .update({
      team_a_player_ids: teamAPlayerIds,
      team_b_player_ids: teamBPlayerIds,
    })
    .eq("id", lobbyId)
    .select(LOBBY_COLUMNS)
    .single();

  if (error) {
    throw error;
  }

  return mapRow(data as LobbyRow);
}

/*
 * --------------------------------------------------------------------------
 * | LOBBY VERLASSEN
 * --------------------------------------------------------------------------
 */

export async function leaveMatchLobby(lobbyId: string, playerId: string): Promise<MatchLobby> {
  const current = await getMatchLobby(lobbyId);

  if (!current) {
    throw new Error("Lobby nicht gefunden.");
  }

  const supabase = createClient();

  const { data, error } = await supabase
    .from("match_lobbies")
    .update({
      team_a_player_ids: current.teamAPlayerIds.filter((id) => id !== playerId),
      team_b_player_ids: current.teamBPlayerIds.filter((id) => id !== playerId),
    })
    .eq("id", lobbyId)
    .select(LOBBY_COLUMNS)
    .single();

  if (error) {
    throw error;
  }

  return mapRow(data as LobbyRow);
}

/*
 * --------------------------------------------------------------------------
 * | MATCH AUS DER LOBBY STARTEN
 * --------------------------------------------------------------------------
 */

export async function startMatchLobby(lobbyId: string): Promise<MatchLobby> {
  const supabase = createClient();

  const { data, error } = await supabase
    .from("match_lobbies")
    .update({ status: "live" })
    .eq("id", lobbyId)
    .select(LOBBY_COLUMNS)
    .single();

  if (error) {
    throw error;
  }

  return mapRow(data as LobbyRow);
}

/*
 * --------------------------------------------------------------------------
 * | LOBBY ALS BEENDET MARKIEREN
 * --------------------------------------------------------------------------
 *
 * NEU: Wird von der Live-Match-Seite aufgerufen, sobald das Match
 * beendet und gespeichert ist. Nur DAS Gerät, das "Match starten"
 * geklickt hat, spielt das Match tatsächlich (siehe PlayerSetup.tsx) -
 * alle anderen Geräte hängen in einem "Warte auf Ergebnis"-Zustand fest
 * und bekommen über genau diesen Statuswechsel per Realtime mit, dass
 * sie zur Match-Historie weiterleiten können.
 * --------------------------------------------------------------------------
 */

export async function finishMatchLobby(lobbyId: string): Promise<MatchLobby> {
  const supabase = createClient();

  const { data, error } = await supabase
    .from("match_lobbies")
    .update({ status: "finished" })
    .eq("id", lobbyId)
    .select(LOBBY_COLUMNS)
    .single();

  if (error) {
    throw error;
  }

  return mapRow(data as LobbyRow);
}

/*
 * --------------------------------------------------------------------------
 * | LIVE-UPDATES ABONNIEREN
 * --------------------------------------------------------------------------
 *
 * Gibt eine Unsubscribe-Funktion zurück (in useEffect als Cleanup nutzen).
 * --------------------------------------------------------------------------
 */

export function subscribeMatchLobby(
  lobbyId: string,
  onChange: (lobby: MatchLobby) => void,
): () => void {
  const supabase = createClient();

  const channel = supabase
    .channel(`match_lobby_${lobbyId}`)
    .on(
      "postgres_changes",
      {
        event: "UPDATE",
        schema: "public",
        table: "match_lobbies",
        filter: `id=eq.${lobbyId}`,
      },
      (payload) => {
        onChange(mapRow(payload.new as LobbyRow));
      },
    )
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
}
